from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Q
from .models import Applicant
from datetime import datetime, timedelta

# ==========================================
# 1. ระบบ Authentication (แอดมิน)
# ==========================================

def admin_login(request):
    error = None
    if request.method == 'POST':
        u = request.POST.get('username')
        p = request.POST.get('password')
        user = authenticate(request, username=u, password=p)
        
        if user is not None:
            login(request, user)
            return redirect('schedule')
        else:
            error = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"
            
    return render(request, 'login.html', {'error': error})

def admin_logout(request):
    logout(request)
    return redirect('home')


# ==========================================
# 2. ส่วนการแสดงผลทั่วไปและสมัครงาน
# ==========================================

def home(request):
    return render(request, 'index.html')

def register(request):
    if request.method == 'POST':
        Applicant.objects.create(
            name=request.POST.get('name'),
            age=request.POST.get('age'),
            education=request.POST.get('education'),
            position=request.POST.get('position'),
            bio=request.POST.get('bio'),
            interview_time=request.POST.get('time_slot')
        )
        return redirect('schedule')

    # สร้างรายการเวลา 08:00 - 18:00 ทุกๆ 10 นาที (กรองเฉพาะที่ว่าง)
    booked_times = Applicant.objects.values_list('interview_time', flat=True)
    time_slots = []
    start_time = datetime.strptime("08:00", "%H:%M")
    end_time = datetime.strptime("18:00", "%H:%M")
    
    while start_time < end_time:
        t = start_time.time()
        if t not in booked_times:
            time_slots.append(t.strftime("%H:%M"))
        start_time += timedelta(minutes=10)
        
    return render(request, 'register.html', {'time_slots': time_slots})


# ==========================================
# 3. ตารางสัมภาษณ์และระบบค้นหาแบบละเอียด
# ==========================================

def schedule(request):
    # รับค่าจากฟอร์มค้นหาเดิม + เพิ่มตำแหน่ง (search_pos)
    search_name = request.GET.get('search_name', '')
    search_age = request.GET.get('search_age', '')
    search_edu = request.GET.get('search_edu', '')
    search_pos = request.GET.get('search_pos', '') # เพิ่มส่วนนี้

    applicants = Applicant.objects.all().order_by('interview_time')

    # กรองข้อมูลตามเงื่อนไข
    if search_name:
        applicants = applicants.filter(name__icontains=search_name)
    if search_age:
        applicants = applicants.filter(age=search_age)
    if search_edu:
        applicants = applicants.filter(education__icontains=search_edu)
    if search_pos: # เพิ่มการกรองตำแหน่ง
        applicants = applicants.filter(position=search_pos)
    
    context = {
        'applicants': applicants,
        'search_name': search_name,
        'search_age': search_age,
        'search_edu': search_edu,
        'search_pos': search_pos, # ส่งค่ากลับไปที่หน้าเว็บเพื่อให้ค้างค่าที่เลือกไว้
    }
    return render(request, 'schedule.html', context)


# ==========================================
# 4. ระบบจัดการข้อมูล (ต้อง Login เป็นแอดมินเท่านั้น)
# ==========================================

@staff_member_required
def edit_applicant(request, pk):
    """ฟังก์ชันแก้ไขข้อมูลผู้สมัคร"""
    # ดึงข้อมูลเดิมจาก ID (pk) ถ้าไม่เจอจะขึ้น 404 Error
    applicant = get_object_or_404(Applicant, pk=pk)
    
    if request.method == 'POST':
        # รับค่าจากฟอร์มมาเขียนทับข้อมูลเดิมใน Database
        applicant.name = request.POST.get('name')
        applicant.age = request.POST.get('age')
        applicant.education = request.POST.get('education')
        applicant.position = request.POST.get('position')
        applicant.bio = request.POST.get('bio')
        applicant.save()  # บันทึกการเปลี่ยนแปลง
        return redirect('schedule')  # บันทึกเสร็จกลับไปหน้าตารางหลัก
    
    # ถ้าเป็น GET (เปิดหน้าเว็บปกติ) ให้ส่งข้อมูลเดิมไปแสดงในฟอร์ม
    return render(request, 'edit_applicant.html', {'applicant': applicant})

@staff_member_required
def delete_applicant(request, pk):
    """ฟังก์ชันลบข้อมูลผู้สมัคร"""
    applicant = get_object_or_404(Applicant, pk=pk)
    applicant.delete()
    return redirect('schedule')