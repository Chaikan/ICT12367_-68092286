from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('schedule/', views.schedule, name='schedule'),
    path('login/', views.admin_login, name='login'),
    path('logout/', views.admin_logout, name='logout'),
    path('edit/<int:pk>/', views.edit_applicant, name='edit_applicant'),
    path('delete/<int:pk>/', views.delete_applicant, name='delete_applicant'),
    path('edit/<int:pk>/', views.edit_applicant, name='edit_applicant'),
]