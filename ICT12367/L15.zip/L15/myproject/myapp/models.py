from django.db import models

class Applicant(models.Model):
    # กำหนดตัวเลือกตำแหน่ง
    POSITIONS = [
        ('Python/Django Developer', 'Python/Django Developer'),
        ('Front-End Developer', 'Front-End Developer'),
        ('IT Support Specialist', 'IT Support Specialist'),
    ]

    name = models.CharField(max_length=100)
    age = models.IntegerField()
    education = models.CharField(max_length=200)
    position = models.CharField(max_length=100, choices=POSITIONS, default='Python/Django Developer') # เพิ่มบรรทัดนี้
    bio = models.TextField()
    interview_time = models.TimeField(unique=True)

    def __str__(self):
        return f"{self.name} - {self.position}"
# Create your models here.
